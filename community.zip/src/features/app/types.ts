export interface InitialStateProps {
    login:boolean
}
